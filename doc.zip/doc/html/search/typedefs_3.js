var searchData=
[
  ['differencetype',['DifferenceType',['../class_generic_member_iterator.html#aaa13c83e6e0d1f5b413d62cacd8f6a2e',1,'GenericMemberIterator']]],
  ['document',['Document',['../document_8h.html#ac6ea5b168e3fe8c7fa532450fc9391f7',1,'document.h']]]
];
