var searchData=
[
  ['ownallocator_5f',['ownAllocator_',['../class_generic_pointer.html#a99b51c07419ee17d57e97774d8ee63ab',1,'GenericPointer']]]
];
