var searchData=
[
  ['backtracking',['backtracking',['../class_tablero.html#a1eafab27f289375dfde026a2ebb039f2',1,'Tablero']]],
  ['basicistreamwrapper',['BasicIStreamWrapper',['../class_basic_i_stream_wrapper.html#a3e9a2dd2b6b28243f8f2a911f67cdf56',1,'BasicIStreamWrapper::BasicIStreamWrapper(StreamType &amp;stream)'],['../class_basic_i_stream_wrapper.html#a7a87c6702f1e98256de416ee101a460f',1,'BasicIStreamWrapper::BasicIStreamWrapper(StreamType &amp;stream, char *buffer, size_t bufferSize)'],['../class_basic_i_stream_wrapper.html#a3e9a2dd2b6b28243f8f2a911f67cdf56',1,'BasicIStreamWrapper::BasicIStreamWrapper(StreamType &amp;stream)'],['../class_basic_i_stream_wrapper.html#a7a87c6702f1e98256de416ee101a460f',1,'BasicIStreamWrapper::BasicIStreamWrapper(StreamType &amp;stream, char *buffer, size_t bufferSize)']]],
  ['bintodec',['bintodec',['../class_poblacion.html#a9601530b4244aea12e428b52ef4552b0',1,'Poblacion']]]
];
