var searchData=
[
  ['stringreftype',['StringRefType',['../class_generic_value.html#a32e0f30ee278072374c8168b14d3317f',1,'GenericValue']]]
];
