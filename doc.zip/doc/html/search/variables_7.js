var searchData=
[
  ['name',['name',['../struct_generic_member.html#a7124f7ccd67421533d33139938604fac',1,'GenericMember::name()'],['../struct_generic_pointer_1_1_token.html#a8aa9b13bd66addb0c0512cfcae72174c',1,'GenericPointer::Token::name()']]],
  ['namebuffer_5f',['nameBuffer_',['../class_generic_pointer.html#a2fd627c663483ad08e4f26707ea5ad86',1,'GenericPointer']]]
];
