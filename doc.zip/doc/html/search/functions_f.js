var searchData=
[
  ['writer',['Writer',['../class_writer.html#af4f54830d6927d9daf5bd53bfd134dd3',1,'Writer']]]
];
