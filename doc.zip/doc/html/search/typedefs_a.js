var searchData=
[
  ['reader',['Reader',['../reader_8h.html#a84f3b66a66647f4ac4267078359188ba',1,'reader.h']]],
  ['reference',['Reference',['../class_generic_member_iterator.html#a8042a85a9e233d65de5b6c66d9a1109a',1,'GenericMemberIterator']]]
];
