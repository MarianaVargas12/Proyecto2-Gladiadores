var searchData=
[
  ['swap',['swap',['../class_generic_document.html#a0d63efcc43758ac3aed77e868233369d',1,'GenericDocument::swap()'],['../class_generic_pointer.html#a249c61b5d4bed20c3f8972c57f46a937',1,'GenericPointer::swap()']]]
];
