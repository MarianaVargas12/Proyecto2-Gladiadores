var searchData=
[
  ['booleantype',['BooleanType',['../struct_parse_result.html#a991cd2759ba802bdb5e960d40890e874',1,'ParseResult']]]
];
