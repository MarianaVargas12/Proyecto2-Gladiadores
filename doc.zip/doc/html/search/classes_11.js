var searchData=
[
  ['writer',['Writer',['../class_writer.html',1,'']]]
];
