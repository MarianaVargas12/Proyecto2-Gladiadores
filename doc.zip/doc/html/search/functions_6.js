var searchData=
[
  ['hasparseerror',['HasParseError',['../class_generic_document.html#a510a0588db4eb372f5d81bc3646578fb',1,'GenericDocument::HasParseError()'],['../class_generic_reader.html#ac417441794477ea747b63adb6d3653a9',1,'GenericReader::HasParseError()']]]
];
