var searchData=
[
  ['tablero',['Tablero',['../class_tablero.html#ab4912f28f1db392e1dd44ddc98bd4f59',1,'Tablero']]],
  ['torre',['torre',['../classtorre.html#aeae1aba1b7a3a67f1abd6d2e504b6762',1,'torre']]],
  ['transcode',['Transcode',['../struct_transcoder.html#a0ea2edfe35784ebf1063921d2bd5fb66',1,'Transcoder']]]
];
