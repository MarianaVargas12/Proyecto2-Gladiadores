var searchData=
[
  ['validate',['Validate',['../struct_transcoder.html#a8a64aa837f7962894a99f63232472543',1,'Transcoder']]]
];
