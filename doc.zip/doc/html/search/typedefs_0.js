var searchData=
[
  ['allocatortype',['AllocatorType',['../class_generic_value.html#a7beb83860c1b8d2a0e2a7da9796b2fa1',1,'GenericValue::AllocatorType()'],['../class_generic_document.html#a35155b912da66ced38d22e2551364c57',1,'GenericDocument::AllocatorType()']]]
];
